// Author:  param3435
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(15);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int a, b, c;
		cin >> a >> b >> c;
	}
	return 0;
}
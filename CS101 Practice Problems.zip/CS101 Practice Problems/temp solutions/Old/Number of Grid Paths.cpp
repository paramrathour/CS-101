// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {
	long long t;
	cin >> t;
	for (long long j = 0; j < t; ++j) {
		long long m, n, prod = 1;
		cin >> m >> n;
		// prod = (m + n - 2)!/((m - 1)! (n - 1)!)
		for (long long i = 1; i < n; ++i) {
			prod *= (i + m - 1);
			prod /= (i);
		}
		cout << prod << "\n";
	}
	return 0;
}
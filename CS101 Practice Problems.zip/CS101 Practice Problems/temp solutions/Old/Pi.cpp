// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {
	long long n;
	cin >> n;
	for (long long i = 0; i < n; ++i) {
		double pi = 0, term = 1;
		long long k;
		cin >> k;
		for (long long j = 0; j < k + 1; ++j) {
			pi += term;
			term *= (j + 1);
			term /= (2 * (j + 1) + 1);
		}
		pi *= 2;
		cout << fixed << setprecision(10) << pi << "\n";
	}
	return 0;
}
// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main()
{
	int sum = 1000;
	for (int a = 1; a < sum; ++a) {
		for (int b = a; b < sum; ++b) {
			int c = sum - (a + b);
			if (a * a + b * b == c * c && c >= b) {
				cout << a << " " << b << " " << c;
				cout << a * b * c;
			}
		}
	}
	return 0;
}
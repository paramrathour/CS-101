#include <simplecpp>

void hilbert(float dist, int n, int parity) {
  // moves forward drawing a curve to left if parity = 1, right if -1.
  left(90 * parity);
  if (n > 0) hilbert(dist, n - 1, -parity);
  forward(dist);        // wait(0.1);
  right(90 * parity);
  if (n > 0) hilbert(dist, n - 1, parity);
  forward(dist);        // wait(0.1);
  if (n > 0) hilbert(dist, n - 1, parity);
  right(90 * parity);   // wait(0.1);
  forward(dist);
  if (n > 0) hilbert(dist, n - 1, -parity);
  left(90 * parity);    // wait(0.1);
}

main_program{
  int n;
  cin >> n;
  turtleSim();
  penDown(false); forward(-170); left(90); forward(-170); right(90); penDown(true);
  hilbert(210 / pow(2.1, n), n, 1);
  wait(5);
}
// Author:  param3435
#include <iostream>
using namespace std;

void printEgyptian(long long numerator, long long denominator) {
	if (denominator == 0 || numerator == 0)
		return;
	else if (denominator % numerator == 0) {
		cout << "1/" << denominator / numerator;
	}
	else if (numerator % denominator == 0) {
		cout << numerator / denominator;
	}
	else if (numerator > denominator) {
		cout << numerator / denominator << " + ";
		printEgyptian(numerator % denominator, denominator);
	}
	else {
		long long n = denominator / numerator + 1;
		cout << "1/" << n << " + ";
		printEgyptian(numerator * n - denominator, denominator * n);
	}
}

int main() {
	long long t, numerator, denominator;
	cin >> t;
	for (long long i = 0; i < t; ++i) {
		cin >> numerator >> denominator;
		printEgyptian(numerator, denominator);
		cout << "\n";
	}
	return 0;
}
// Author:  param3435
#include <iostream>
using namespace std;

const int startAlpha = 65;
char Char(int n) {
	return char(n + startAlpha);
}
int findNextLargeDisk(int arr[], int n, int k) {
	for (int i = 1; i < n; ++i)
		if (arr[i] == k)
			return i;
	return 22;
}
void hanoi(int n) {
	int positions[22] = {0};					// Location of rod where i+1th disk is.	0 for A, 1 for B, 2 for C.
	// All disks at rod A initially
	int topDisks[3] = {1, 22, 22};	 			// Maintains topDisks at eack rod
	int step = n % 2 == 1 ? 1 : 2;				// We go clockwise for odd n and anticlockwise for even n
	int numberOfSteps = (1 << n) - 1;           // Number of Steps till solution will be 2^n-1

	while (true)
	{	// Moving smallest disk
		cout << "Disk " <<  1 << " from " << Char(positions[0]);
		topDisks[positions[0]] = findNextLargeDisk(positions, n, positions[0]);
		positions[0] = (positions[0] + step) % 3;
		topDisks[positions[0]] = 0;
		cout << " to " << Char(positions[0]) << "\n";

		numberOfSteps = numberOfSteps - 1;

		if (numberOfSteps == 0)                 // Break if Solution reached
			break;
		// Doing the only move possible without moving smallest disk
		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 3; ++j)
				if ((i != j) && (topDisks[i] < topDisks[j]) && (topDisks[i] != 0))
				{
					cout << "Disk " <<  topDisks[i] + 1 << " from " << Char(i) << " to " << Char(j) << "\n";
					positions[topDisks[i]] = j;
					topDisks[j] = topDisks[i];
					topDisks[i] = findNextLargeDisk(positions, n, i);
					goto breakbothloops;
				}
breakbothloops:
		numberOfSteps = numberOfSteps - 1;
	}

}

int main() {
	int t;
	cin >> t;
	for (int i = 0; i < t; ++i) {
		int n;
		cin >> n;
		hanoi(n);
		cout << "\n";
	}
	return 0;
}
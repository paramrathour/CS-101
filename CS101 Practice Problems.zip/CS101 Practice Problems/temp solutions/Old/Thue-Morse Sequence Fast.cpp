// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {

	int n, len, num;
	bool odd_ones;
	cin >> n;
	len = (1 << n);
	for (int i = 0; i < len; ++i) {
		// cout << __builtin_parityll(i);		// = 1  when numberOfOnes in binary representation of n is odd
		odd_ones = false;
		num = i;
		while (num) {
			odd_ones ^= (num % 2);
			num /= 2;
		}
		cout << (odd_ones ? 1 : 0);
	}
	return 0;
}
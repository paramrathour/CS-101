// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {
    long long t;
    cin >> t;
    for (long long j = 0; j < t; ++j) {
        long long m, n, sum = 0, term = 1, temp;
        cin >> m >> n;
        if (m > n) {
            temp = n;
            n = m;
            m = temp;
        }
        // sum = sum of (m k)*(n k) for k = 0, 1, ..., min(m,n)
        for (long long i = 0; i <= m; ++i) {
            sum += term;
            term *= (m - i);
            term *= (n - i);
            term *= 2;
            term /= (i + 1);
            term /= (i + 1);
        }
        cout << sum << "\n";
    }
    return 0;
}
// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {

	long long T = 1;
	cin >> T;
	for (long long i = 0; i < T; ++i) {
		long long n, phi, t;
		cin >> n;
		phi = n;
		if (n % 2 == 0) {
			phi *= 1;
			phi /= 2;
			while (n % 2 == 0) {
				n /= 2;
			}
		}
		if (n % 3 == 0) {
			phi *= 2;
			phi /= 3;
			while (n % 3 == 0) {
				n /= 3;
			}
		}
		for (long long i = 6; (i - 1) * (i - 1) <= n; i += 6) {
			t = i - 1;
			if (n % t == 0) {
				phi *= (t - 1);
				phi /= t;
				while (n % t == 0) {
					n /= t;
				}
			}
			t = i + 1;
			if (n % t == 0) {
				phi *= (t - 1);
				phi /= t;
				while (n % t == 0) {
					n /= t;
				}
			}
		}
		if (n > 1) {
			phi *= (n - 1);
			phi /= n;
		}
		cout << phi << "\n";
	}
	return 0;
}
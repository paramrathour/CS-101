// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

bool nth_term(int n) {
	if (n == 0) {
		return false;
	}
	if (n % 2) {
		return 1 - nth_term(n / 2);
	}
	else {
		return nth_term(n / 2);
	}
}

int main() {
	long long n, len;
	cin >> n;
	len = (1 << n);
	for (long long i = 0; i < len; ++i) {
		cout << nth_term(i);
	}
	return 0;
}
// Author:  param3435
//https://en.wikipedia.org/wiki/Catalan_number
//https://oeis.org/A000108/list

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

const long long m = 1000000007;
long long catalanNumbers[10000] = {0};

long long ways(long long n) {
	long long numberOfWays = 0;
	if (n == 0)
		numberOfWays = 1;
	else if (catalanNumbers[n] != 0)
		return catalanNumbers[n];
	else {
		for (long long i = 0; i < n; ++i) {
			numberOfWays = numberOfWays + ways(i) * ways(n - 1 - i);
			numberOfWays = numberOfWays % m;
		}
		catalanNumbers[n] = numberOfWays;
	}
	return numberOfWays;
}

int main() {
	long long t;
	cin >> t;
	for (long long i = 0; i < t; ++i) {
		long long n;
		cin >> n;
		cout << ways(n) << "\n";
	}
	return 0;
}
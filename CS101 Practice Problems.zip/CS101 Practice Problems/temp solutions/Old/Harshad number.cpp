// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n, k, sum, num;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		sum = 0;
		cin >> k;
		num = k;
		while (k != 0) {
			sum += (k % 10);
			k /= 10;
		}
		cout << ((num % sum) ? "no" : "yes") << "\n";
	}
	return 0;
}
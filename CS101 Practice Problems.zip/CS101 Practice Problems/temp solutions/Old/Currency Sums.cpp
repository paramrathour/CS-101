// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	long long t, k, temp, numberOfCoins;
	cin >> numberOfCoins;
	long long coins[numberOfCoins];
	for (int i = 0; i < numberOfCoins; ++i) {
		cin >> temp;
		coins[i] = temp;
	}
	cin >> t;
	for (long long i = 0; i < t; ++i) {
		cin >> k;
		long long ways[k + 1][numberOfCoins + 1];
		for (long long i = 1; i <= k; ++i) {
			ways[i][numberOfCoins] = 0;
		}
		for (long long i = 0; i <= numberOfCoins; ++i) {
			ways[0][i] = 1;
		}
		for (long long i = 0; i <= k; ++i) {
			for (long long j = numberOfCoins - 1; j >= 0; --j) {
				ways[i][j] = ways[i][j + 1];
				temp = i - coins[j];
				if (temp >= 0) {
					ways[i][j] += ways[temp][j];
				}
			}
		}
		cout << ways[k][0] << "\n";
	}
	return 0;
}
// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	long long t, n, jump, idx;
	cin >> t;
	for (long long k = 0; k < t; ++k) {
		cin >> n;
		long long arr[n];
		for (int i = 0; i < n; ++i)
			cin >> arr[i];
		jump = 0;
		for (long long b = n / 2; b >= 1; b /= 2) {
			idx = jump + b;
			if (idx < n && (arr[idx] >= arr[idx - 1] || arr[idx] <= arr[idx + 1]))
				jump += b;
		}
		cout << arr[jump] << "\n";
	}
	return 0;
}
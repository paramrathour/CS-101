// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {
	long long t;
	cin >> t;
	for (long long i = 0; i < t; ++i) {
		long long n, x, p = 0, coefficient;
		cin >> x >> n;
		for (long long j = 0; j <= n; ++j) {
			cin >> coefficient;
			p *= x;
			p += coefficient;
		}
		cout << p << " ";
	}
	return 0;
}
#include <bits/stdc++.h>
using namespace std;

#define r                 1000000007

long long fastExp(long long x, long long n, long long p) {      // x^n % p
	long long ans = 1;
	while (n != 0) {
		if ((n % 2) == 1) {
			ans *= x;
			ans %= p;
		}
		x = x * x;
		x %= p;
		n /= 2;
	}
	return ans;
}

int main() {

	long long T = 1;
	cin >> T;
	for (int i = 0; i < T; ++i) {
		long long a, b;
		cin >> a >> b;
		cout << fastExp(a, b, r) << "\n";
	}
	return 0;
}
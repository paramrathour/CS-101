// Author:  param3435
#include <iostream>
using namespace std;

int main()
{
	cout << fixed;
	cout.precision(8);
	long long n, int_b, int_d, base_b = 2, base_d = 10, base_exp_i = 1, num_i, count_decimal = 8;
	double k, frac_b, frac_d, num_f, base_exp_bf, epsilon = 1e-9, base_exp_df;
	cin >> n;
	for (long long i = 0; i < n; ++i) {
		cin >> k;
		int_d = k, int_b = 0;
		frac_d = k - int_d, frac_b = 0;
		base_exp_i = 1; base_exp_bf = 1;
		num_i = int_d, num_f = frac_d;
		while (num_i) {
			if (num_i % base_b) {
				int_b += base_exp_i;
			}
			base_exp_i *= base_d;
			num_i /= base_b;
		}
		base_exp_df = 1;
		for (int i = 0; i < count_decimal; ++i) {
			base_exp_bf /= base_b;
			base_exp_df /= base_d;
			if ((num_f - base_exp_bf) >= 0) {
				num_f -= base_exp_bf;
				frac_b += base_exp_df;
			}
		}
		cout << int_b + frac_b << "\n";
	}
	return 0;
}
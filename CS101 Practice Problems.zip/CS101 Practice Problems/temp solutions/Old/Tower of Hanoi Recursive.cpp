// Author:  param3435
#include <iostream>
using namespace std;

void hanoi(int n, int a, int b) {
	int other = 6 - a - b;
	if (n <= 0) {
		return;
	}
	hanoi(n - 1, a, other);
	cout << "Disk " << n << " from " << char(a + 'A' - 1) << " to " << char(b + 'A' - 1) << "\n";
	hanoi(n - 1, other, b);
}

int main() {
	int t;
	cin >> t;
	for (int i = 0; i < t; ++i) {
		int n;
		cin >> n;
		hanoi(n, 1, 2);
		cout << "\n";
	}
	return 0;
}
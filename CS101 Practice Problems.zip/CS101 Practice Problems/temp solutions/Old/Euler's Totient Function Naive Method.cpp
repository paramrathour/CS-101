// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

long long gcd(long long x, long long y) {
	if (y > x) {
		long long t = y;
		y = x;
		x = t;
	}

	while (y != 0) {
		long long mod = x % y;
		x = y;
		y = mod;
	}
	return x;
}

int main() {

	long long T = 1;
	cin >> T;
	for (int i = 0; i < T; ++i) {
		long long n, phi = 0;
		cin >> n;
		for (int j = 1; j <= n; ++j) {
			if (gcd(n, j) == 1) {
				phi++;
			}
		}
		cout << phi << "\n";
	}
	return 0;
}
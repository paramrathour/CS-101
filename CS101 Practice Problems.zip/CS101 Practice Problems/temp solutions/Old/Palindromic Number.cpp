// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n, k, rev, num;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		rev = 0;
		cin >> k;
		num = k;
		while (k != 0) {
			rev *= 10;
			rev += (k % 10);
			k /= 10;
		}
		cout << ((rev == num) ? "yes" : "no") << "\n";
	}
	return 0;
}
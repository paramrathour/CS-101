// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

void Hereditary(int num, int base) {
	if (num < base) {
		cout << num;
		return;
	}
	bool first = true;
	int count = 0;
	while (num != 0) {
		int rem = num % base;
		if (rem) {
			if (rem != 1) {
				cout << rem << "*";
			}
			cout << base << "^{";
			Hereditary(count, base);
			cout << "}";
			first = false;
		}
		count++;
		num /= base;
		if ((!first) && (num % base != 0)) {
			cout << " + ";
		}
	}
	return;
}

int main() {
	int num, base;
	cin >> num >> base;
	Hereditary(num, base);
	return 0;
}
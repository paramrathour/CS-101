// Author:  param3435
//https://stackoverflow.com/questions/12775920/reading-line-of-integers-into-a-vector
//https://stackoverflow.com/questions/19094283/quicksort-and-tail-recursive-optimization
//CLRS Problem 7.4 209
#include <bits/stdc++.h>
using namespace std;

long long Partition(vector<long long> &numbers, long long p, long long r) {
	long long x = numbers[r];
	long long i = p - 1;
	for (long long j = p; j < r; ++j)
		if (numbers[j] <= x) {
			i++;
			swap(numbers[i], numbers[j]);
		}
	swap(numbers[i + 1], numbers[r]);
	return i + 1;
}

void Quicksort(vector<long long> &numbers, long long p, long long r) {
	while (p < r) {
		long long q = Partition(numbers, p, r);
		if (q < (r - p) / 2) {
			Quicksort(numbers, p, q - 1);
			p = q + 1;
		}
		else {
			Quicksort(numbers, q + 1, r);
			r = q - 1;
		}
	}
}

void printVector(vector<long long> &numbers, long long n) {
	for (long long i = 0; i < n; ++i)
		cout << numbers[i] << " ";
	cout << "\n";
}

int main() {
	long long t;
	cin >> t;
	long long n, num;
	string line;
	getline(cin, line);
	for (long long i = 0; i < t; ++i) {
		vector<long long> numbers;
		getline(cin, line);
		istringstream iss(line);
		while (iss >> num)
			numbers.push_back(num);
		n = numbers.size();
		Quicksort(numbers, 0, n - 1);
		printVector(numbers, n);
	}
	return 0;
}
// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {
  long long n, k;
  cin >> n;
  long long a = 0, b = 1, c = 1, d = n, a_new, b_new, c_new, d_new;
  cout << a << "/" << b << " ";
  while (c <= n) {
    k = (n + b) / d;
    // {a, b, c, d} = {c, d, k * c - a, k * d - b};
    a_new = c;
    b_new = d;
    c_new = k * c - a;
    d_new = k * d - b;
    a = a_new;
    b = b_new;
    c = c_new;
    d = d_new;
    cout << a << "/" << b << " ";
  }
  return 0;
}
// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	int total_test_cases, base = -2, base_ = 10;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, num = 0, remainder, quotient, exp = 1;
		cin >> n;
		while (n) {
			remainder = n % base;
			quotient = n / base;
			if (remainder < 0) {
				quotient++;
				remainder -= base;
			}
			num += remainder * exp;
			exp *= base_;
			n = quotient;
		}
		cout << num << "\n";
	}
	return 0;
}
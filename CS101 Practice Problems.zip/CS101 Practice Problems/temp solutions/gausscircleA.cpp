// Author:  param3435
#include <iostream>
using namespace std;

int X(int n);
int count_lattice_points(int n);

int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, sum = 0, max_norm;
		cin >> n;
		max_norm = n;
		for (int i = 0; i <= max_norm; ++i) {
			sum += count_lattice_points(i);
		}
		cout << sum << " ";
	}
	return 0;
}

int X(int n) {
	if (n % 4 == 1)
		return 1;
	else if (n % 4 == 3)
		return -1;
	else
		return 0;
}

int count_lattice_points(int n) {
	if (n == 0) {
		return 1;
	}
	int i, sum = 0;
	for (i = 1; i * i < n; ++i) {
		if (n % i == 0) {
			sum += X(i);
			sum += X(n / i);
		}
	}
	if (i * i == n) {
		sum += X(i);
	}
	return 4 * sum;
}
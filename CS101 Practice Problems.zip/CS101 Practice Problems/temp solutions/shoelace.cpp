// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(1);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, sum = 0;
		cin >> n; // n >= 3
		int x, y, x_prev, y_prev, x_init, y_init;
		cin >> x_prev >> y_prev;
		x_init = x_prev;
		y_init = y_prev;
		repeat(n - 1) {
			cin >> x >> y;
			sum += (x_prev * y - x * y_prev);
			x_prev = x;
			y_prev = y;
		}
		sum += (x * y_init - x_init * y);
		cout << abs(sum / 2.0) << "\n";
	}
	return 0;
}
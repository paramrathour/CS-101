// Author:  param3435
#include<iostream>
using namespace std;

int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, a, height = 1;
		cin >> n >> a; // n >= 1
		bool previous = a;
		if (previous) {
			height++;
		}
		for (int i = 0; i < n - 1; ++i) {
			cin >> a;
			if (height == -1) {
				continue;
			}
			if (a) {
				if (previous)
					height += 5;
				else
					height += 1;
			}
			else if (!previous)
			{
				height = -1;
			}
			previous = a;
		}
		cout << height << "\n";
	}
}
// Author:  param3435
#include <iostream>
using namespace std;

void convergent(int i, int &numerator, int &denominator, int n) {
	int a_i, temp;
	cin >> a_i;
	if (i == n) {
		numerator = 1;
		denominator = a_i;
	}
	if (i < n) {
		convergent(i + 1, numerator, denominator, n);
		temp = denominator;
		numerator += (denominator * a_i);
		denominator = numerator;
		numerator = temp;
	}
	if (i == 0) {
		cout << denominator;
		if (numerator > 1) {
			cout << "/" << numerator;
		}
		cout << "\n";
	}
	return;
}

// Helper Code
int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, numerator = 0, denominator = 0;
		cin >> n;
		convergent(0, numerator, denominator, n);
	}
	return 0;
}
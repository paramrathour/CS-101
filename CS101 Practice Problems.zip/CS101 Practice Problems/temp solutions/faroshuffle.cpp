// Author:  param3435
#include <iostream>
using namespace std;

void faro_shuffle(char key[], int length, bool outer) {
	char key_new[length], key_temp[length + 1];
	for (int i = 0; i < length ; i++) {
		key_temp[i] = key[i];
	}
	key_temp[length] = key_temp[length / 2];
	for (int i = 0; i <= length / 2; i++) {
		key_new[2 * i + !outer] = key_temp[i];
		key_new[2 * i + outer] = key_temp[i + (length + 1) / 2];
	}
	for (int i = 0; i < length ; i++) {
		key[i] = key_new[i];
	}
}

int main() {
	const int LENGTH_MAX = 1e5;
	char key[LENGTH_MAX];
	bool outer;
	int total_test_cases, length = 0;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		cin >> outer >> length;
		for (int i = 0; i < length; ++i) {
			cin >> key[i];
		}
		faro_shuffle(key, length, outer);
		for (int i = 0; i < length; ++i) {
			cout << key[i];
		}
		cout << "\n";
	}
	return 0;
}
// Author: param3435
#include <iostream>
using namespace std;

void convergents(int i, int n, int &numerator, int &denominator) {
	int a_i, temp;
	cin >> a_i;
	if (i == n) {
		numerator = 1;
		denominator = a_i;
	}
	if (i < n) {
		convergents(i + 1, n, numerator, denominator);
		temp = denominator;
		numerator += (denominator * a_i);
		denominator = numerator;
		numerator = temp;
	}
	if (i == 0) {
		cout << denominator;
		if (numerator > 1) {
			cout << "/" << numerator;
		}
		cout << "\n";
	}
	return;
}

/*void indices(int numerator, int denominator, int a_0) {
	if (denominator == 0) {
		return;
	}
	if (a_0) {
		indices(denominator, numerator - a_0 * denominator, 0);
		return;
	}
	int numerator / denominator
	if (numerator % denominator == 0) {
		cout <<  << " ";
	}
	indices(denominator, numerator % denominator, 0);
}*/

// Helper Code
int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, numerator = 0, denominator = 0;
		cin >> n;
		convergents(0, n, numerator, denominator);
	}
	/*for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int numerator, denominator, a_0;
		cin >> numerator >> denominator >> a_0;
		indices(numerator, denominator, a_0);
		cout << "\n";
	}*/
	return 0;
}
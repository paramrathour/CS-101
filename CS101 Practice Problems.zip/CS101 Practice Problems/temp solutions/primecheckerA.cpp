// Author: param3435
#include <iostream>
using namespace std;

bool prime_check(int n) {
	if (n <= 3) {
		return n > 1;
	}
	if (n % 2 == 0 || n % 3 == 0) {
		return false;
	}
	for (int i = 5; i * i <= n; i += 6) {
		if (n % i == 0 || n % (i + 2) == 0) {
			return false;
		}
	}
	return true;
}

// Helper Code
int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		cin >> n;
		cout << (prime_check(n) ? "yes" : "no") << "\n";
	}
	return 0;
}
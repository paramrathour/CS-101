// Author:  param3435
#include <iostream>
using namespace std;

int count_of_divisors(long long n) {
	int count = 0, i;
	for (i = 1; i * i < n; ++i) {
		if (n % i == 0) {
			count += 2;
		}
	}
	if (i * i == n) {
		count++;
	}
	return count;
}

bool anti_prime_check(long long n) {
	int count = count_of_divisors(n);
	for (long long i = 1; i < n; ++i) {
		if (count <= count_of_divisors(i)) {
			return false;
		}
	}
	return true;
}

int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		long long n;
		cin >> n;
		cout << (anti_prime_check(n) ? "yes" : "no") << "\n";
	}
	return 0;
}
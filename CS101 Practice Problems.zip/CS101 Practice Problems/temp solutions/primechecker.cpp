// Author: param3435
#include <simplecpp>

bool prime_check(int n) {
	if (n <= 3) {
		return n > 1;
	}
	if (n % 2 == 0 || n % 3 == 0) {
		return false;
	}
	for (int i = 5; i * i <= n; i += 6) {
		if (n % i == 0 || n % (i + 2) == 0) {
			return false;
		}
	}
	return true;
}

// Helper Code
main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n;
		cout << (prime_check(n) ? "yes" : "no") << "\n";
	}
	return 0;
}
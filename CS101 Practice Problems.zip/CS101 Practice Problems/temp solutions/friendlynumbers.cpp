// Author:  param3435
#include <simplecpp>

long long gcd(long long a, long long b) {
	long long nexta, nextb;
	while (a % b != 0) {
		nexta = b;
		nextb = a % b;
		a = nexta;
		b = nextb;
	}
	return b;
}

long long sum_of_divisors(long long n) {
	long long sum = 0, i;
	for (i = 1; i * i < n; ++i) {
		if (n % i == 0) {
			sum += i;
			sum += n / i;
		}
	}
	if (i * i == n) {
		sum += i;
	}
	return sum;
}

bool friendly_check(long long a, long long b) {
	long long sum_a, sum_b,  gcd_a, gcd_b, num_a, den_a, num_b, den_b;
	sum_a = sum_of_divisors(a), sum_b = sum_of_divisors(b);
	gcd_a = gcd(a, sum_a), gcd_b = gcd(b, sum_b);
	num_a = sum_a / gcd_a, num_b = sum_b / gcd_b;
	den_a = a / gcd_a, den_b = b / gcd_b;
	/*cout << sum_a << " " << sum_b << "\n";
	cout << gcd_a << " " << gcd_b << "\n";
	cout << num_a << " " << num_b << "\n";
	cout << den_a << " " << den_b << "\n";*/
	if (num_a == num_b && den_a == den_b) {
		cout << sum_a / gcd_a;
		if (a / gcd_a != 1) {
			cout << "/" << a / gcd_a;
		}
		return true;
	}
	else {
		cout << -1;
		return false;
	}
}

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		long long a, b;
		cin >> a >> b;
		friendly_check(a, b);
		cout << "\n";
	}
	return 0;
}
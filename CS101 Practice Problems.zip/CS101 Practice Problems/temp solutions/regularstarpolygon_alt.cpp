#include<simplecpp>

int gcd(int a, int b) {
	int nexta, nextb;
	while (a % b != 0) {
		nexta = b;
		nextb = a % b;
		a = nexta;
		b = nextb;
	}
	return b;
}

main_program{
	int n, m, iterations_outer, iterations_inner, gcdnm;
	cin >> n >> m;
	gcdnm = gcd(n, m);
	iterations_inner = 1, iterations_outer = n;
	double sides = (double)n / m, length = 80;
	double circumradius = length / (2 * sine(180 / sides)), angle_of_arc = (double)360 / n, interior_angle = 180 * (sides - 2) / sides;
	if (gcdnm != 1) {
		iterations_inner = n / gcdnm, iterations_outer = gcdnm;
	}
	// Initialization
	turtleSim();
	penUp();
	forward(-40);
	left(90);
	forward(80);
	right(90);
	penDown();
	// Drawing
	for (int i = 0; i < iterations_outer; ++i) {
		repeat(iterations_inner) {
			forward(length);
			right(360 / sides);
		}
		if (i == iterations_outer - 1) {
			break;
		}
		if (gcdnm != 1) {
			penUp();
			left((double)180 * (n - (m + 1)) / n - interior_angle); //(double)180 * (n - (m + 1)) / n -
			forward(circumradius * 2 * sine(angle_of_arc / 2));
			right(180 - (double)180 * (n - (m + 1)) / n);
			penDown();
		}
	}
	wait(10);
}
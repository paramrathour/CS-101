// Author:  param3435
#include<iostream>
#include <cmath>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(5);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		double p, x_i, norm = 0;
		cin >> p >> n; // n >= 1
		for (long long i = 0; i < n; ++i) {
			cin >> x_i;
			if (p != 0)
				norm += pow(abs(x_i), p);
			else
				norm = max(norm, abs(x_i));
		}
		if (p != 0) {
			norm = pow(norm, (double) 1 / p);
		}
		cout << norm << "\n";
	}
}
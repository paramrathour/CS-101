// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		cin >> n;
		double sum = 0;
		for (int i = 1; i <= n; ++i) {
			sum += (double) 1 / i;
		}
		cout << sum << "\n";
	}
	return 0;
}
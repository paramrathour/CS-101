// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int k, numerator = 2, denominator = 1;
		double pi = 1;
		cin >> k;
		repeat(k) {
			pi *= numerator;
			pi *= numerator;
			pi /= denominator;
			denominator += 2;
			pi /= denominator;
			numerator += 2;
		}
		pi *= 2;
		cout << pi << "\n";
	}
	return 0;
}
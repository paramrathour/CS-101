// Author:  param3435
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(15);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		cin >> n; // n >= 0
		long double pi = 2, radical = 0;
		for (int i = 0; i <= n; ++i) {
			pi *= 2;
			radical = sqrt(2 + radical);
			pi /= radical;
		}
		cout << pi << "\n";
	}
	return 0;
}
// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		cin >> n;
		int num_stars = 1, num_spaces = 2 * n - 1, max_stars = 2 * n + 1;
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < num_stars; ++j) {
				cout << "* ";
			}
			for (int j = 0; j < num_spaces; ++j) {
				cout << "  ";
			}
			for (int j = 0; j < num_stars; ++j) {
				cout << "* ";
			}
			cout << "\n";
			num_stars++;
			num_spaces -= 2;
		}
		for (int i = 0; i < max_stars; ++i) {
			cout << "* ";
		}
		cout << "\n";
		for (int i = 0; i < n; ++i) {
			num_spaces += 2;
			num_stars--;
			for (int j = 0; j < num_stars; ++j) {
				cout << "* ";
			}
			for (int j = 0; j < num_spaces; ++j) {
				cout << "  ";
			}
			for (int j = 0; j < num_stars; ++j) {
				cout << "* ";
			}
			cout << "\n";
		}
		cout << "\n";
	}
	return 0;
}
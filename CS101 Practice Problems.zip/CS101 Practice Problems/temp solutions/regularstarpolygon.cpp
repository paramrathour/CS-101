#include<simplecpp>

main_program{
	int n, m;
	cin >> n >> m;
	turtleSim();
	double length = 100;
	repeat(n) {
		forward(length);
		right((double) 360.0 * m / n);
		wait(1);
	}
	wait(10);
}
// Author:  param3435
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		cin >> n; // n >= 2
		int j = n;
		double radical = 1;
		for (int i = 1; i <= n - 1; ++i) {
			radical = sqrt(1 + j * radical);
			j--;
		}
		cout << radical << "\n";
	}
	return 0;
}
// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int a, b, c, max_side, min_side, middle_side;
		cin >> a >> b >> c;
		min_side = min(a, min(b, c));
		max_side = max(a, max(b, c));
		middle_side = a + b + c - (min_side + max_side);
		if (max_side >= min_side + middle_side) {
			cout << "NOT A TRIANGLE!";
		}
		else {
			if (min_side == max_side) {
				cout << "Equilateral";
			}
			else if ((middle_side == min_side) || (middle_side == max_side)) {
				cout << "Isosceles  ";
			}
			else {
				cout << "Scalene    ";
			}
			cout << " & ";
			int x = max_side * max_side, y = min_side * min_side + middle_side * middle_side;
			if (x < y) {
				cout << "Acute";
			}
			else if (x == y) {
				cout << "Right";
			}
			else {
				cout << "Obtuse";
			}
		}
		cout << "\n";
	}
	return 0;
}
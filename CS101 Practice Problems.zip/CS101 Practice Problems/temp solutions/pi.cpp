// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		double pi = 0, term = 1;
		int k, j = 0;
		cin >> k;
		repeat(k + 1) {
			pi += term;
			term *= (j + 1);
			term /= (2 * (j + 1) + 1);
			j++;
		}
		pi *= 2;
		cout << pi << "\n";
	}
	return 0;
}
// Author:  param3435
#include <simplecpp>

// convergents
main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, a_0, a_n;
		cin >> n; // n >= 1
		cin >> a_n;
		int numerator = 1, denominator = a_n, temp;
		repeat(n) {
			cin >> a_n;
			temp = denominator;
			numerator += (denominator * a_n);
			denominator = numerator;
			numerator = temp;
		}
		cout << denominator << "/" << numerator << "\n";
	}
	return 0;
}
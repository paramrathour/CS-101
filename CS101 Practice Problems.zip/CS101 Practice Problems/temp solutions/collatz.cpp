#include <iostream>
using namespace std;

void f(long long &n);
int count_operations(long long n);

int main() {
	long long n;
	cin >> n;
	while (n >= 0) {
		cout << count_operations(n) << "\n";
		cin >> n;
	}
	return 0;
}

void f(long long &n) {
	if (n % 2)
		n = 3 * n + 1;
	else
		n /= 2;
}

int count_operations(long long n) {
	int count = 0;
	while (n != 1) {
		f(n);
		count++;
	}
	return count;
}
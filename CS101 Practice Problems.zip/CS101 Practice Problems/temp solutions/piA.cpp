// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(10);
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		double pi = 0, term = 1;
		int k;
		cin >> k;
		for (int j = 0; j < k + 1; ++j) {
			pi += term;
			term *= (j + 1);
			term /= (2 * (j + 1) + 1);
		}
		pi *= 2;
		cout << pi << "\n";
	}
	return 0;
}
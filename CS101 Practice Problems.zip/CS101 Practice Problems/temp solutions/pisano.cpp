// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, fibonacci_previous = 0, fibonacci_current = 1, fibonacci_next, period = 0;
		cin >> n;
		do {
			fibonacci_next = fibonacci_current + fibonacci_previous;
			fibonacci_previous = fibonacci_current % n;
			fibonacci_current = fibonacci_next % n;
			period++;
		} while (!(fibonacci_previous == 0 && fibonacci_current == 1));
		cout << period << "\n";
	}
	return 0;
}
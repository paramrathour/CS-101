// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int main() {
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		cin >> n;
		int a = 0, b = 1, c = 1, d = n, a_new, b_new, c_new, d_new, k;
		cout << a << "/" << b << " ";
		while (c <= n) {
			k = (n + b) / d;
			// {a, b, c, d} = {c, d, k * c - a, k * d - b};
			a_new = c;
			b_new = d;
			c_new = k * c - a;
			d_new = k * d - b;
			a = a_new;
			b = b_new;
			c = c_new;
			d = d_new;
			cout << a << "/" << b << " ";
		}
		cout << "\n";
	}
	return 0;
}
// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, i = 1;
		cin >> n;
		double sum = 0;
		repeat(n) {
			sum += (double) 1 / i;
			i++;
		}
		cout << sum << "\n";
	}
	return 0;
}
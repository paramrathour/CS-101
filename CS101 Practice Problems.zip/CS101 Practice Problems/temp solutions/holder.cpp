// Author:  param3435
#include<iostream>
#include<cmath>
#include<cfloat>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(5);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n;
		double x_i, minimum = DBL_MAX, harmonic = 0, geometric = 1, arithmetic = 0, rms = 0, cubic = 0, maximum = DBL_MIN;
		cin >> n; // n >= 1
		for (int i = 0; i < n; ++i) {
			cin >> x_i;
			minimum = min(minimum, x_i);
			harmonic += 1 / x_i;
			geometric *= x_i;
			arithmetic += x_i;
			rms += x_i * x_i;
			cubic += x_i * x_i * x_i;
			maximum = max(maximum, x_i);
		}
		harmonic = n / harmonic;
		geometric = pow(geometric, (double) 1 / n);
		arithmetic /= n;
		rms /= n;
		rms = sqrt(rms);
		cubic /= n;
		cubic = pow(cubic, (double) 1 / 3);
		cout << minimum << " " << harmonic << " " << geometric << " " << arithmetic << " " << rms << " " << cubic << " " << maximum << "\n";
	}
}
// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n;
		int num_stars = 1, num_spaces = 2 * n - 1, max_stars = 2 * n + 1;
		repeat(n) {
			repeat(num_stars) {
				cout << "* ";
			}
			repeat(num_spaces) {
				cout << "  ";
			}
			repeat(num_stars) {
				cout << "* ";
			}
			cout << "\n";
			num_stars++;
			num_spaces -= 2;
		}
		repeat(max_stars) {
			cout << "* ";
		}
		cout << "\n";
		repeat(n) {
			num_spaces += 2;
			num_stars--;
			repeat(num_stars) {
				cout << "* ";
			}
			repeat(num_spaces) {
				cout << "  ";
			}
			repeat(num_stars) {
				cout << "* ";
			}
			cout << "\n";
		}
		cout << "\n";
	}
	return 0;
}
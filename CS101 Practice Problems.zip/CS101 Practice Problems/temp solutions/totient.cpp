// Author:  param3435
#include <bits/stdc++.h>
using namespace std;

int totient(int n);
void update_phi(int &phi, int m);
void exterminate(int &n, int m);

int main() {
	int T = 1, n;
	cin >> T;
	for (int i = 0; i < T; ++i) {
		cin >> n;
		cout << totient(n) << "\n";
	}
	return 0;
}

int totient(int n) {
	int phi, t;
	phi = n;
	if (n % 2 == 0) {
		update_phi(phi, 2);
		exterminate(n, 2);
	}
	if (n % 3 == 0) {
		update_phi(phi, 3);
		exterminate(n, 3);
	}
	for (int i = 6; (i - 1) * (i - 1) <= n; i += 6) {
		t = i - 1;
		if (n % t == 0) {
			update_phi(phi, t);
			exterminate(n, t);
		}
		t = i + 1;
		if (n % t == 0) {
			update_phi(phi, t);
			exterminate(n, t);
		}
	}
	if (n > 1) {
		update_phi(phi, n);
	}
	return phi;
}

void update_phi(int &phi, int m) {
	phi *= (m - 1);
	phi /= m;
}

void exterminate(int &n, int m) {
	while (n % m == 0) {
		n /= m;
	}
}
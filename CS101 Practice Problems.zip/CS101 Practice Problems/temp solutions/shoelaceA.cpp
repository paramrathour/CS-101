// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(1);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		int n, sum = 0;
		cin >> n; // n >= 3
		int x, y, x_prev, y_prev, x_init, y_init;
		cin >> x_prev >> y_prev;
		x_init = x_prev;
		y_init = y_prev;
		for (int i = 0; i < n - 1; ++i) {
			cin >> x >> y;
			sum += (x_prev * y - x * y_prev);
			x_prev = x;
			y_prev = y;
		}
		sum += (x * y_init - x_init * y);
		cout << abs(sum / 2.0) << "\n";
	}
	return 0;
}
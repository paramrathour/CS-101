// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, i = 0;
		cin >> n;
		repeat(n + 1) {
			int term = 1, denominator = 1, numerator = i;
			repeat(i + 1) {
				cout << term << " ";
				term *= numerator;
				term /= denominator;
				denominator++;
				numerator--;
			}
			cout << "\n";
			i++;
		}
		cout << "\n";
	}
	return 0;
}
// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		double tower = 1, a, n;
		cin >> a >> n; // n >= 1
		repeat(n) {
			tower = pow(a, tower);
		}
		cout << tower << "\n";
	}
	return 0;
}
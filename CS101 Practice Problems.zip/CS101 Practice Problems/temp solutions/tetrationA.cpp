// Author:  param3435
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	for (int test_case = 0; test_case < total_test_cases; ++test_case) {
		double tower = 1, a, n;
		cin >> a >> n; // n >= 1
		for (int i = 1; i <= n; ++i) {
			tower = pow(a, tower);
		}
		cout << tower << "\n";
	}
	return 0;
}
// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n; // n >= 2
		int j = n;
		long double radical = 1;
		repeat(n - 1) {
			radical = sqrt(1 + j * radical);
			j--;
		}
		cout << radical << "\n";
	}
	return 0;
}
// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(10);
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		int k;
		cin >> k;
		double fraction = 1, sum = 1, product = 1;
		for (int j = 1; j <= k; ++j) {
			product /= (2 * j + 1);
			sum += product;
		}
		int a = 1, b = k;
		for (int j = 1; j <= k; ++j) {
			fraction =  b / fraction;
			fraction += a;
			b--;
		}
		fraction = 1 / fraction;
		/*cout << "product = " << product << "\n";
		cout << "fraction = " << fraction << "\n";
		cout << "sum = " << sum << "\n";*/
		cout << fraction + sum << "\n";
	}
	return 0;
}
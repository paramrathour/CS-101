// Author:  param3435
#include <iostream>
using namespace std;

int main() {
	cout << fixed;
	cout.precision(10);
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		int k, numerator = 2, denominator = 1;
		double pi = 1;
		cin >> k;
		for (int j = 0; j < k; ++j) {
			pi *= numerator;
			pi *= numerator;
			pi /= denominator;
			denominator += 2;
			pi /= denominator;
			numerator += 2;
		}
		pi *= 2;
		cout << pi << "\n";
	}
	return 0;
}
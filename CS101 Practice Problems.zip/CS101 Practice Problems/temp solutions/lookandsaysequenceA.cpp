// Author:  param3435
#include <iostream>
using namespace std;

void look_and_say(int sequence_given[], int &length_given, const int LENGTH_MAX) {
	if (length_given == 0) {
		length_given = 1;
		sequence_given[length_given - 1] = 1;
		return;
	}
	int length_new = 2;
	int sequence_new[LENGTH_MAX] = {1};
	sequence_new[1] = sequence_given[0];
	for (int i = 1; i < length_given; ++i) {
		if (sequence_given[i] == sequence_given[i - 1]) {
			sequence_new[length_new - 2]++;
		}
		else {
			length_new += 2;
			sequence_new[length_new - 2]++;
			sequence_new[length_new - 1] = sequence_given[i];
		}
	}
	for (int i = 0; i < length_new; ++i) {
		sequence_given[i] = sequence_new[i];
	}
	length_given = length_new;
}

int main() {
	const int LENGTH_MAX = 1e5;
	int LSS[LENGTH_MAX], length = 0;
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		look_and_say(LSS, length, LENGTH_MAX);
		for (int j = 0; j < length; ++j) {
			cout << LSS[j];
		}
		cout << "\n";
	}
	return 0;
}
#include<simplecpp>

main_program {
	cout << fixed;
	cout.precision(15);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
	}
}

poetic patterns
iteration admiration iteration fixation, iteration salvation, iteration domination, iteration foundations
function protection, function direction, function admiration
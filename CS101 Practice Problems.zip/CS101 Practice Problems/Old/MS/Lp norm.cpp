// Author:  param3435
#include<simplecpp>

main_program{
	cout << fixed;
	cout.precision(5);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		double p, x_i, norm = 0;
		cin >> p >> n; // n >= 1
		repeat(n) {
			cin >> x_i;
			if (p != 0)
				norm += pow(abs(x_i), p);
			else
				norm = max(norm, abs(x_i));
		}
		if (p != 0) {
			norm = pow(norm, (double) 1 / p);
		}
		cout << norm << "\n";
	}
}
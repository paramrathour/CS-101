// Author:  param3435
#include <simplecpp>

main_program {
	int sum = 1000, a = 1, b, c;
	repeat(sum - a) {
		b = a;
		repeat(sum - b) {
			c = sum - (a + b);
			if (a * a + b * b == c * c && c >= b) {
				cout << a * b * c;
			}
			b++;
		}
		a++;
	}
	return 0;
}
/*
2017 Endsem Paper _ Solutions (other interesting problem rotate matrix)
The below provided code has recursive implementations for finding the Determinant and
Adjoint of the matrix using calls to computing the Co - Factor for specific elements. You need
	to fill the blanks in the code for the functions Co - Factor, Determinant and Adjoint.*/
#include <simplecpp>
struct Matrix {
	int matrix[400];
	int rows;
	int columns;
	Matrix(int r, int c) {
		rows = r;
		columns = c;
		for (int i = 0; i < 400; i++)
			matrix[i] = 0;
	}
	Matrix(int given_matrix[20][20], int r, int c) {
		rows = r;
		columns = c;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				matrix[ i * columns + j ] = given_matrix[i][j]; 2 marks
			}
		}
	}
	Matrix& operator=(const Matrix& rhs) {
		if (&rhs == this)
			return *this ; 0.5 marks
		for (int i = 0; i < rhs.rows * rhs.columns; i++)
			matrix[i] = rhs.matrix[i];
		if (rhs.rows * rhs.columns < rows * columns) {
			for (int i = rhs.rows * rhs.columns ; i < rows * columns; i++)
				matrix[i] = 0; 1 mark
		}
		rows = rhs.rows;
		columns = rhs.columns;
		return *this ; 0.5 marks
	}
	~Matrix() {}
	int& operator()(int r, int c) {
		if ( r >= rows || r < 0 || c >= columns || c < 0 ) 1 mark
			cout << "Index out of bounds" << endl;
		return matrix[ r * columns + c ]; 1 mark
	}
	Matrix operator/(int scalar) {
		Matrix result(rows, columns);
		if (scalar != 0) {
			for (int i = 0; i < rows * columns; i++) {
				result.matrix[i] = matrix[i] / scalar ; 1 mark
			}
		}
		return result;
	}
	void printmat() {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++)
				cout << matrix[ i * columns + j ] << " "; 1 mark
			cout << endl;
		}
	}
};
/* Co-Factor of Matrix M of size n x n of the (p,q)th element */
Matrix getCofactor(Matrix M, int p, int q, int n) {
	int i = 0, j = 0;
	Matrix temp(n - 1, n - 1);
	for (int row = 0; row < n; row++) {
		for (int col = 0; col < n; col++) {
			if ( row != p && col != q ) {
				1 mark
				temp(i, j) = M(row, col); 1 mark
				j++;
				if (j == n - 1) {
					j = 0 ; 1.5 marks
					i++ ; 1.5 marks
				}
			}
		}
	}
	return temp;
}
/* Determinant of Matrix M whose size is n x n */
int determinant(Matrix mat, int n) {
	int D = 0, sign = 1;
	if (n == 1)
		return mat(0, 0) ; //Also acceptable mat.matrix[0] 1 mark
	Matrix temp(n, n);
	for (int f = 0; f < n; f++) {
		temp = getCofactor( mat, 0, f, n ); 1 mark
		D += sign * mat(0, f) * determinant( temp, n - 1 ); 1 mark
		sign = -sign;
	}
	return D;
}
/*Adjoint of Matrix M whose size is n x n*/
Matrix adjoint(Matrix A, int n) {
	Matrix adj(n, n);
	if (n == 1) {
		adj(0, 0) = 1 ; //Also acceptable adj.matrix[0] = 1 ; 1 mark
		return adj;
	}
	int sign = 1;
	Matrix temp(n, n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			temp = getCofactor( A, i, j, n ); 1 mark
			sign = ((i + j) % 2 == 0) ? 1 : -1; 1 mark
			adj(j, i) = (sign) * (determinant(temp, n - 1)); 1 mark
		}
	}
	return adj;
}
/*Inverse of Matrix M whose size is n x n*/
Matrix inverse(Matrix A, int n) {
	Matrix inverse(n, n);
	int det = determinant(A, n);
	Matrix adj = adjoint(A, n);
	inverse = adj / det;
	return inverse;
}
main_program {
	int m, n;
	cin >> m >> n;
	int array[20][20];
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++)
			cin >> array[i][j];
	}
	Matrix A(array, m, n);
	if (m == n) {
		if (determinant(A, m) != 0)
			inverse(A, n).printmat();
	}
}
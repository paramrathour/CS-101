#include <iostream>

//Using the ideas discussed with my TA (Param Rathour)
//(I was unable to come up with the solution myself)

using namespace std;

int main() {
	int num[4];
	for (int i = 0; i < 4; ++i)
	{
		cout<<num[i];
	}

}

#include<simplecpp>

void pattern(int n)
{
int static a;

if(n==0){

forward(30);
pattern(n-1);

}
if(n<0 && n> (-1*a-1) ){
repeat(50){
forward(1);
left(360.0/100);
}

repeat(50){
forward(1);
right(360.0/100);
}
pattern(n-1);
}
if(n>0){
a=a+1;
repeat(50){
forward(1);
right(360.0/100);
}
repeat(50){
forward(1);
right(-360.0/100);
}
 pattern(n-1);
}
}



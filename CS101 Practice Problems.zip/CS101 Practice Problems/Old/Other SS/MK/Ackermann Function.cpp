#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int A(int m, int n){
   if (m==0)
     return n+1;
   else if (n==0)
     return A(m-1,1);
   else
     return A(m-1,A(m,n-1));

}

int main(){
  int t;
  cin>>t;
  int out[t];
  for (int i=0;i<t;i++){
    int m,n;
    cin>>m>>n;
    out[i]=A(m,n);
}
  for (int i=0;i<t;i++)
    cout<<out[i]<<endl;
}

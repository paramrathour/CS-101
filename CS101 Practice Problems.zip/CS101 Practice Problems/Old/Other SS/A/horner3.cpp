#include<simplecpp>
int main()
{
int k;cin>>k;
repeat(k)
{
int n;cin>>n;
int arr[n+1];
int x;cin>>x;
int value=0;
for(int i=0;i<n+1;i++)cin>>arr[i];
for(int i=n;i>=0;i--)
value=value*x +arr[i];
cout<<value;
}
}

#include<simplecpp>
int order(int* arr,int start,int end)
{
int x=(start+end)/2;
while(start<=x&&x<end)
{

if(arr[x]>arr[x+1])
{
return order(arr,start,x);
}
else
{
return order(arr,x+1,end);
}
}
return x;
}

main_program
{
int n;cin>>n;int arr[n];
for(int i=0;i<n;i++)cin>>arr[i];
int index=order(arr,0,n-1);
cout<<arr[index];


}

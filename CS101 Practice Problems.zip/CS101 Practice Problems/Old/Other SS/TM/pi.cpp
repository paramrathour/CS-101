#include <iostream>
#include <iomanip>

using namespace std;

long double factorial(long double n);
long double double_factorial(long double n);

int main() {
	int n;
	cin >> n;


	long double terms[n];

	for (int i = 0; i < n; i++) {
		cin >> terms[i];

	}
	
	for (long double m: terms) {
		long double pi = 0;

		for (long double i = 0; i <= m; i++) {
			pi += (factorial(i) / double_factorial(2 * i + 1));
		}

		pi *= 2;

		cout << fixed << setprecision(10) << pi << endl;
	}
}

long double factorial(long double n) {
	long double prod = 1;
	for (long double i = 2; i <= n; i++) {
		prod *= i;
	}
	return prod;
}


long double double_factorial(long double n) {
	long double prod = 1;
	for (long double i = 3; i <= n; i+= 2) {
		prod *= i;
	}
	return prod;
}

#include<bits/stdc++.h> 
  
using namespace std; 
  
long long count( long long S[], long long m, long long n ) 
{ 
    long long i, j, x, y; 
  
    // We need n+1 rows as the table  
    // is constructed in bottom up 
    // manner using the base case 0 
    // value case (n = 0) 
    long long table[n + 1][m]; 
      
    // Fill the enteries for 0 
    // value case (n = 0) 
    for (i = 0; i < m; i++) 
        table[0][i] = 1; 
  
    // Fill rest of the table entries  
    // in bottom up manner  
    for (i = 1; i < n + 1; i++) 
    { 
        for (j = 0; j < m; j++) 
        { 
            // Count of solutions including S[j] 
            x = (i-S[j] >= 0) ? table[i - S[j]][j] : 0; 
  
            // Count of solutions excluding S[j] 
            y = (j >= 1) ? table[i][j - 1] : 0; 
  
            // total count 
            table[i][j] = x + y; 
        } 
    } 
    return table[n][m - 1]; 
} 
  
// Driver Code 
int main() 
{ 
    long long arr[] = {1, 2, 5, 10, 20, 50, 100, 200, 500, 2000}; 
    long long m = sizeof(arr)/sizeof(arr[0]); 
    long long num[] = {1, 2, 5, 10, 20, 50, 100, 200, 500, 2000}; 
    long long n = sizeof(num)/sizeof(num[0]); 
    for (long long i = 0; i < n; ++i)
    {
    cout << count(arr, m, num[i]) << endl; 
    }
    return 0; 
} 
  
// This code is contributed 
// by Akanksha Rai(Abby_akku) 
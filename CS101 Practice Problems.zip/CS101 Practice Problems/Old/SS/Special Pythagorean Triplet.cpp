// Author:  param3435
#include <simplecpp>

main_program {
	int sum = 1000, a, b, c;
	// calculate a, b, c and output abc
	return 0;
}
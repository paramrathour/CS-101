// Author:  param3435
#include<simplecpp>

main_program{
	cout << fixed;
	cout.precision(55);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		double p, x_i, norm = 0;
		cin >> p >> n; // n >= 1
		// calculate norm here
		cout << norm << "\n";
	}
}
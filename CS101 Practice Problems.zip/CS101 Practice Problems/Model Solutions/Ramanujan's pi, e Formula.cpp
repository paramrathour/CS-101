// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int k;
		cin >> k;
		double fraction = 1, sum = 1, product = 1;
		int j = 1;
		repeat(k) {
			product /= (2 * j + 1);
			sum += product;
		}
		int a = 1, b = k;
		repeat(k) {
			fraction = b / fraction;
			fraction += a;
			b--;
		}
		fraction = 1 / fraction;
		cout << fraction + sum << "\n";
	}
	return 0;
}
// Author: param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(8);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		double k;
		cin >> k;
		long long n, int_b, int_d, base_b = 2, base_d = 10, base_exp_i = 1, num_i, count_decimal = 8;
		double frac_b, frac_d, num_f, base_exp_f, epsilon = 1e-9;
		int_b = k, int_d = 0;
		frac_b = k - int_b, frac_d = 0;
		base_exp_i = 1; base_exp_f = 1;
		num_i = int_b, num_f = frac_b;
		while (num_i) {
			if (num_i % base_d) {
				int_d += base_exp_i;
			}
			base_exp_i *= base_b;
			num_i /= base_d;
		}
		repeat(count_decimal) {
			base_exp_f /= base_b;
			num_f *= base_d;
			if (num_f >= 1 - epsilon) {
				frac_d += base_exp_f;
				num_f -= 1;
			}
		}
		cout << int_d + frac_d << "\t";
	}
	return 0;
}
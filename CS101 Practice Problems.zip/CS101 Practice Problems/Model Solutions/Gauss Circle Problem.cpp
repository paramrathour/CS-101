// Author:  param3435
#include <simplecpp>

int X(int n);
int count_lattice_points(int n);

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat (total_test_cases) {
		int n, sum = 0, max_norm;
		cin >> n;
		max_norm = n * n;
		for (int i = 0; i <= max_norm; ++i) {
			sum += count_lattice_points(i);
		}
		cout << sum << " ";
	}
	return 0;
}

int X(int n) {
	if (n % 4 == 1)
		return 1;
	else if (n % 4 == 3)
		return -1;
	else
		return 0;
}

int count_lattice_points(int n) {
	int sum = 0;
	if (n == 0) {
		return 1;
	}
	int i;
	for (i = 1; i * i < n; ++i) {
		if (n % i == 0) {
			sum += X(i);
			sum += X(n / i);
		}
	}
	if (i * i == n) {
		sum += X(i);
	}
	return 4 * sum;
}
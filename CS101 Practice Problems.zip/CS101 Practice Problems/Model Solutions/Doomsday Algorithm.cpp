// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int date, month, year, century, year_mod_100;
		char c;
		cin >> date >> c >> month >> c >> year;
		century = year / 100;
		year_mod_100 = year % 100;
		bool validity = false, leap_year = ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
		int doomsday = 2, doomsdate, doomsdate_jan = 3 + leap_year, doomsdate_feb = 28 + leap_year, doomsdate_mar = 14, doomsdate_apr = 4, doomsdate_may = 9, doomsdate_jun = 6, doomsdate_jul = 11, doomsdate_aug = 8, doomsdate_sep = 5, doomsdate_oct = 10, doomsdate_nov = 7, doomsdate_dec = 12;
		// Validity Check
		if (month == 2) {
			if (date >= 0 && date <= 28 + leap_year) {
				validity = true;
			}
		}
		else if (month >= 1 && month <= 7) {
			if (date >= 0 && date <= 30 + month % 2) {
				validity = true;
			}
		}
		else if (month >= 8 && month <= 12) {
			if (date >= 0 && date <= 31 - month % 2) {
				validity = true;
			}
		}
		if (!validity) {
			cout << "INVALID DATE!";
			continue;
		}
		// ------------------- Doomsday Algorithm ------------------
		// Century
		repeat(century) {
			doomsday += 5;
			if (i % 4 == 3) {
				doomsday++;
			}
		}
		// Year
		doomsday += year_mod_100 + (year_mod_100) / 4;
		// doomsday += (year_mod_100 / 12) + (year_mod_100 % 12) + (year_mod_100 % 12) / 4;
		// Doomsdate selection
		switch (month) {
		case 1: doomsdate = doomsdate_jan;
			break;
		case 2: doomsdate = doomsdate_feb;
			break;
		case 3: doomsdate = doomsdate_mar;
			break;
		case 4: doomsdate = doomsdate_apr;
			break;
		case 5: doomsdate = doomsdate_may;
			break;
		case 6: doomsdate = doomsdate_jun;
			break;
		case 7: doomsdate = doomsdate_jul;
			break;
		case 8: doomsdate = doomsdate_aug;
			break;
		case 9: doomsdate = doomsdate_sep;
			break;
		case 10: doomsdate = doomsdate_oct;
			break;
		case 11: doomsdate = doomsdate_nov;
			break;
		case 12: doomsdate = doomsdate_dec;
			break;
		}
		// Difference in Dates
		doomsday += ((date - doomsdate + 7) % 7);
		doomsday %= 7;
		switch (doomsday) {
		case 0: cout << "Sunday";
			break;
		case 1: cout << "Monday";
			break;
		case 2: cout << "Tuesday";
			break;
		case 3: cout << "Wednesday";
			break;
		case 4: cout << "Thursday";
			break;
		case 5: cout << "Friday";
			break;
		case 6: cout << "Saturday";
			break;
		}
		cout << "\n";
	}
	return 0;
}
#include<simplecpp>

main_program{
    int total_test_cases;
    cin >> total_test_cases;
    repeat(total_test_cases) {
        int digit = -1;
        char c;
        int checksum = 0, position, i = 10;
        repeat(10) {
            cin >> c;
            if (c >= '0' && c <= '9') {
                checksum += (i * int(c - '0'));
            }
            else if (c == 'X') {
                checksum += (i * 10);
            }
            else if (c == '?') {
                position = i;
            }
            else {
                cout << "Invalid Input";
            }
            i--;
        }
        checksum %= 11, i = 0;
        repeat(11) {
            int temp = checksum + position * i;
            temp %= 11;
            if (temp == 0) {
                digit = i;
                break;
            }
            i++;
        }
        if (digit == 10)
            cout << "X";
        else if (digit >= 0 && digit <= 9)
            cout << digit;
        else
            cout << "No digit found";
        cout << "\n";
    }
}
// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, a, height = 1;
		cin >> n; // n >= 1
		cin >> a;
		bool previous = a;
		if (previous) {
			height++;
		}
		repeat(n - 1) {
			cin >> a;
			if (height == -1) {
				continue;
			}
			if (a) {
				if (previous)
					height += 5;
				else
					height += 1;
			}
			else if (!previous)
			{
				height = -1;
			}
			previous = a;
		}
		cout << height << "\n";
	}
}
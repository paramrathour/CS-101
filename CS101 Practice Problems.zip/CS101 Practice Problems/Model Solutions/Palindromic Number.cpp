// Author:  param3435
#include<simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n;
		int reverse_num = 0, num = n;
		while (n != 0) {
			reverse_num *= 10;
			reverse_num += (n % 10);
			n /= 10;
		}
		cout << ((reverse_num == num) ? "yes" : "no") << "\n";
	}
	return 0;
}
// Author:  param3435
#include<simplecpp>

main_program {
	cout << fixed;
	cout.precision(4);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int hours, minutes, seconds;
		char c;
		cin >> hours >> c >> minutes >> c >> seconds; // n >= 1
		double angle_hour, angle_minute, angle_second, angle_hm, angle_hs, angle_ms;
		if (hours > 12) {
			hours -= 12;
		}
		angle_hour = 30 * (hours + (double) minutes / 60 + (double) seconds / 3600);
		angle_minute = 6 * (minutes + (double) seconds / 60);
		angle_second = 6 * (seconds);
		angle_hm = abs(angle_hour - angle_minute);
		angle_hs = abs(angle_hour - angle_second);
		angle_ms = abs(angle_minute - angle_second);
		angle_hm = min(angle_hm, 360 - angle_hm);
		angle_hs = min(angle_hs, 360 - angle_hs);
		angle_ms = min(angle_ms, 360 - angle_ms);
		cout << angle_hm << "\t" << angle_hs << "\t" << angle_ms << "\n";
	}
	return 0;
}
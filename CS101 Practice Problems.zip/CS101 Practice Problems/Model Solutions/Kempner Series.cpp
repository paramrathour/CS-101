// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n;
		double sum = 0;
		int num;
		bool no_nines;
		for (int i = 1; i <= n; ++i) {
			num = i;
			no_nines = true;
			while (num) {
				if (num % 10 == 9) {
					no_nines = false;
					break;
				}
				num /= 10;
			}
			if (no_nines) {
				sum += (double) 1 / i;
			}
		}
		cout << sum << "\n";
	}
	return 0;
}
// Author:  param3435
#include<simplecpp>

void update_phi(int &phi, int m);
void exterminate(int &n, int m);
int totient(int n);

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, phi, t;
		cin >> n;
		cout << totient(n) << "\n";
	}
	return 0;
}

void update_phi(int &phi, int m) {
	phi *= (m - 1);
	phi /= m;
}

void exterminate(int &n, int m) {
	while (n % m == 0) {
		n /= m;
	}
}

int totient(int n) {
	int phi, t;
	phi = n;
	if (n % 2 == 0) {
		update_phi(phi, 2);
		exterminate(n, 2);
	}
	if (n % 3 == 0) {
		update_phi(phi, 3);
		exterminate(n, 3);
	}
	for (int i = 6; (i - 1) * (i - 1) <= n; i += 6) {
		t = i - 1;
		if (n % t == 0) {
			update_phi(phi, t);
			exterminate(n, t);
		}
		t = i + 1;
		if (n % t == 0) {
			update_phi(phi, t);
			exterminate(n, t);
		}
	}
	if (n > 1) {
		update_phi(phi, n);
	}
	return phi;
}
// Author:  param3435
#include<simplecpp>

main_program {
	cout << fixed;
	cout.precision(15);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int ordinates_num, interval_count;
		cin >> ordinates_num; // ordinates_num >= 3
		interval_count = ordinates_num - 1;
		long double pi = 0;
		long double lower = 0, upper = 1, step_size = (upper - lower) / interval_count, current = lower;
		pi += (pow(current, 4) * pow(1 - current, 4) / (1 + pow(current, 2)));
		current += step_size;
		repeat(interval_count / 2 - 1) {
			pi += (4 * pow(current, 4) * pow(1 - current, 4) / (1 + pow(current, 2)));
			current += step_size;
			pi += (2 * pow(current, 4) * pow(1 - current, 4) / (1 + pow(current, 2)));
			current += step_size;
		}
		pi += (4 * pow(current, 4) * pow(1 - current, 4) / (1 + pow(current, 2)));
		current += step_size;
		pi += (pow(current, 4) * pow(1 - current, 4) / (1 + pow(current, 2)));
		pi *= step_size / 3;
		pi = (long double) 22 / 7 - pi;
		cout << pi << "\n";
	}
	return 0;
}
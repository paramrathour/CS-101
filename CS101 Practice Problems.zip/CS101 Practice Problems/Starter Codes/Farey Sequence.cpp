// Author:  param3435
#include<simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n;
		// print the terms here
		cout << "\n";
	}
	return 0;
}
// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int a, b, c;
		cin >> a >> b >> c;
		// determine types and output accordingly
		cout << "\n";
	}
	return 0;
}
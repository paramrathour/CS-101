#include<simplecpp>

int totient(int n);

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, phi, t;
		cin >> n;
		cout << totient(n) << "\n";
	}
	return 0;
}

int totient(int n) {
	int phi, t;
	// calculate phi
	return phi;
}
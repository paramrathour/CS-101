// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, a_n;
		cin >> n; // n >= 0
		cin >> a_n;
		// calculate and output p/q here
	}
	return 0;
}
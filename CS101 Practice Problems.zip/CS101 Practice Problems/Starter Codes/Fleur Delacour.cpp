// Author:  param3435
#include <simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, a, height = 1;
		cin >> n; // n >= 1
		// calculate height
		cout << height << "\n";
	}
}
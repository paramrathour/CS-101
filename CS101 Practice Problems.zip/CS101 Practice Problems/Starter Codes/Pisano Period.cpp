// Author:  param3435
#include<simplecpp>

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, fibonacci_previous = 0, fibonacci_current = 1, fibonacci_next, period = 0;
		cin >> n;
		// calculate the period here
		cout << period << "\n";
	}
	return 0;
}
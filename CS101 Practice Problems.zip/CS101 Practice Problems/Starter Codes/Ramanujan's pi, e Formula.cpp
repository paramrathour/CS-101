// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int k;
		cin >> k;
		double fraction = 1, sum = 1, product = 1;
		// calculate fraction and sum here
		cout << fraction + sum << "\n";
	}
	return 0;
}
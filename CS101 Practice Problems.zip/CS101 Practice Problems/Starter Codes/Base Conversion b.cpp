/// Author: param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(8);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		double k;
		cin >> k;
		// convert and output
	}
	return 0;
}
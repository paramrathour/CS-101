// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(10);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int k
		cin >> k;
		double pi = 1;
		// calculate pi here;
		cout << pi << "\n";
	}
	return 0;
}
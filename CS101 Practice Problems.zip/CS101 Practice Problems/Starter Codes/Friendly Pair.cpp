// Author:  param3435
#include <simplecpp>

long long sum_of_divisors(long long n);
bool friendly_pair_check(long long a, long long b);

main_program {
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		long long a, b;
		cin >> a >> b;
		friendly_pair_check(a, b);
		cout << "\n";
	}
	return 0;
}

long long sum_of_divisors(long long n) {
	// return the sum of divisors of n
}

bool friendly_pair_check(long long a, long long b) {
	// check if a,b are friendly and output the common abundancy index or -1 accordingly
}
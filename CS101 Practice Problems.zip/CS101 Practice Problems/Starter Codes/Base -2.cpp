// Author:  param3435
#include<simplecpp>

main_program {
	int total_test_cases, base = -2, base_ = 10;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n, num = 0, remainder, quotient, base_exp = 1;
		cin >> n;
		// calculate num here
		cout << num << "\n";
	}
	return 0;
}
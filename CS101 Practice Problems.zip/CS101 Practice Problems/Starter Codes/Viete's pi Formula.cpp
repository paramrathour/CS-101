// Author:  param3435
#include <simplecpp>

main_program {
	cout << fixed;
	cout.precision(15);
	int total_test_cases;
	cin >> total_test_cases;
	repeat(total_test_cases) {
		int n;
		cin >> n; // n >= 0
		long double pi = 1, radical = 0;
		// calculate pi here
		cout << pi << "\n";
	}
	return 0;
}

Add problems from other sections (link arrays, continued fractions problems in recursion)
credit to wikipedia, codeforces
✓ Add in disclaimer about concept needed to solve (exception 0), use long long for int and double for floating point
✓ Typecasting
Order of proference table
✓ tips link
✓ instructions - choose data type carefully
✓ concept needed - repeat variables and data types

✓ new environment for helper code, constraints
✓ links for test cases (input/output)

✓ Preface, over the years, hope u enjoy/learn new, solved using given concepts

# Introduction
+ Hilbert Curve (mention other graphics problems)

# Loops I (repeat)
* Peace Symbol
## Pattern Printing
* ✓ Butterfly
* ✓ Pascal Triangle
	https://youtu.be/0iMtlus-afo Pascal's Triangle - Numberphile

## Infinite Expressions 
+ ✓ Infinite Sum (Harmonic numbers H_n, π)
+ ✓ Infinite Product (π: wallis product)
+ ✓ Infinite Nested Radicals (Ramanujan's infinite radical)
+ ✓ Infinite Continued Fractions
+ ✓ Infinite Power Towers
	Tetration, https://en.wikipedia.org/wiki/Tetration#Extension_to_infinite_heights
### Mix
+ ✓ Ramanujan sqrt(PiE)
+ ✓ Viète's expression for π
+ ✓ Holder Mean
+ ✓ Area of Convex Polygon (Shoelace Formula, Integer points for simplicity, Clockwise or AntiClockwise)
+ ✓ Simpson's Rule

# Conditionals
<!-- + Special Pythagorean Triplet -->
+ ✓ Type of Triangle (given 3 sides - Scalene, Isosceles, Equilateral, NOT A TRIANGLE or Acute, Right, Obtuse)
* Life of a Flower, Fleur Delacour
	https://codeforces.com/contest/1591/problem/A
<!-- * Lp Norm -->
<!-- * Type of roots -->
* ✓ Angle between hour and minute
	https://www.geeksforgeeks.org/calculate-angle-hour-hand-minute-hand/
+ ✓ ISBN
	11.11.11 - Numberphile https://youtu.be/sPFWfAxIiwg
+ ✓ Calendar (Doomsday method, https://en.wikipedia.org/wiki/Doomsday_rule)
<!-- * Fair Playoff
	https://codeforces.com/contest/1535/problem/A -->

# Loops II (for, while)
+ ✓ Pisano Period
<!-- + Harshad number -->
+ ✓ Palindromic number
+ ✓ Base -2
+ ✓ Base Conversion
+ ✓ Kempner Series
* Sum of Cubes
	https://codeforces.com/contest/1490/problem/C
+ ✓ Farey Sequence
	https://youtu.be/DpwUVExX27E Infinite Fractions - Numberphile
* Frobenius Number

# Functions
(Calendar)
+ ✓  Collatz Conjecture
*	Polygonal number
+ ✓ Euler's Totient Function (Prime Factorise)
<!-- * Discrete Logarithm (Inverse problem of Modular Exponentiation) -->
+ ✓ Friendly Numbers (Sum of Divisors, Equivalent Fractions print abundancy index if integer no fraction)
	https://youtu.be/KZ1BVlURwfI A Video about the Number 10 - Numberphile
<!-- * ✓ Prime Checker -->
<!-- * ✓ AntiPrime Checker -->
* ✓ Gauss circle problem (Count Lattice Points inside a circle, https://en.wikipedia.org/wiki/Gauss_circle_problem)
	Using Chi function
		Pi hiding in prime regularities: https://youtu.be/NaL_Cb42WyY
		Dirichlet character: https://en.wikipedia.org/wiki/Dirichlet_character
	Output is pi?
* Regular Star Polygons
	https://en.wikipedia.org/wiki/Star_polygon
	Schläfli symbol: https://en.wikipedia.org/wiki/Schl%C3%A4fli_symbol
* MMI

# Recursion I
+ Ackermann function
* Continued Fractions
	Generating a_i
	✓ Generating num/den
+ GridPaths and Delannoy Numbers ((find iterative solution using math))
+ Modular Exponentiation
+ Egyptian Fraction
+ Dyck Words
+ Partitions
+ Hereditary Representation
+ Horner's method (recursion with correct order)

# Arrays I
+ Josephus Problem
+ Thue-Morse Sequence aka Fair Share Sequence
* ✓ LFSR
* ✓ Perfect Faro Shuffle (Outer and Inner)
* ✓ Vignere Cipher, key rotation check 720 (can do Perfect Faro Shuffle (Inner))
* Long Comparison
	https://codeforces.com/contest/1613/problem/A
* Lunar Arithmetic (Dismal Arithmetic)
	https://youtu.be/cZkGeR9CWbk, https://en.wikipedia.org/wiki/Lunar_arithmetic
# Function and Arrays
+ Currency Sums
* ✓ Look-and-say Sequence
	https://www.youtube.com/watch?v=ea7lJkEhytA Look-and-Say Numbers (feat John Conway) - Numberphile
* ✓ Formatter (aLtErNaTiNg cApS, tOGGLE cASE, Capitalize Each Word, UPPERCASE, lowercase, Sentence case)
	sentence case becomes capital after .?!
<!-- * Valid Brackets -->
* ✓ Recaman Sequence with Drawing
* Ulam Spiral (Sieve of Eratosthenes)
* the Van Eck Sequence

# Arrays II
* ✓ Gray Code (throwback to LFSR)
+ Remove Duplicates (Sorted array and unsorted array (do in nlogn))
	https://codeforces.com/contest/978/problem/A
+ Majority Element (Give situation, Moore's Voting Algorithm)
+ Large Factorials
* Rotate a matrix
* Counting Sort
* Sandpiles
* Brainfuck Compiler (short as cell size, dynamically size array)

# Recursion and Arrays
+ Tower of Hanoi
+ Maximum Element
+ QuickSort
* Determinant of a matrix
* Huffman Code
* FFT (polynomial multiplication)


# Classes
+ Polynomials
+ Linear Algebra (add Matrix Rotation)
+ Symbolic Computation aka Computer algebra
* Infinite Precision Arithmetic
* Fractions as numerators and denominators

# Project
* Tennis Scoreboard Simulator
* Moustique Cipher
* Minesweeper
* Sudoku Solver
* Game of Life
* Langton's Ant

# Advanced Concepts
- Macros
- Bitwise Operators
- Standard Template Library
- Divide and Conquer
- Dynamic Programming
- Greedy Algorithms
- Backtracking

## Bitwise
## STL
CodeForces